// I2cEepromBlock.h
#ifndef I2C_EEPROM_BLOCK_H
#define I2C_EEPROM_BLOCK_H

#include <Arduino.h>
#include <Wire.h>

// PUBLIC - damit im .ino verfügbar
struct BlockHeader {
  uint16_t token;
  uint16_t crc;
};

class I2cEepromBlock {
public:
  I2cEepromBlock(uint8_t i2cAddr, uint16_t userSize, uint8_t sdaPin = 21, uint8_t sclPin = 22);

  ~I2cEepromBlock();

  void begin();
  void task();

  uint8_t* data();
  const uint8_t* data() const;

  void markDirty();
  bool isDirty() const {
    return _dirty;
  }

  uint16_t userSize() const {
    return _userSize;
  }
  uint16_t blockSize() const {
    return _blockSize;
  }
  uint8_t numBlocks() const {
    return _numBlocks;
  }
  uint16_t currentToken() const {
    return _currentToken;
  }
  int currentBlockIndex() const {
    return _currentBlockIndex;
  }
  // Für externe Verifikation
  bool readBlock(int blockIdx, BlockHeader& header, uint8_t* buffer) const;
  
private:
  // Constants
  static constexpr uint16_t EEPROM_SIZE = 4096;
  static constexpr uint8_t PAGE_SIZE = 32;
  static constexpr uint8_t WRITE_DELAY_MS = 5;

  struct BlockHeader {
    uint16_t token;  // 2 bytes
    uint16_t crc;    // 2 bytes
  };
  static constexpr uint16_t HEADER_SIZE = sizeof(BlockHeader);  // 4 bytes

  // State
  uint8_t _i2cAddr;
  uint16_t _userSize;
  uint16_t _blockSize;
  uint8_t _numBlocks;
  uint8_t _sdaPin, _sclPin;

  uint16_t _currentToken;
  int _currentBlockIndex;

  bool _dirty;
  bool _initialized;

  // Double buffer
  uint8_t* _bufA;
  uint8_t* _bufB;
  uint8_t* _activeBuf;
  uint8_t* _inactiveBuf;

  // Write state machine
  enum class State { Idle,
                     WritingHeader,
                     WritingData };
  State _state;
  int _writeBlockIndex;
  uint16_t _writeOffset;
  BlockHeader _preparedHeader;

  // Methods
  uint16_t blockBaseAddress(int blockIdx) const;
  uint16_t crc16_ccitt(const uint8_t* data, uint16_t len) const;
  bool readBlock(int blockIdx, BlockHeader& header, uint8_t* buffer) const;
  void writeBytes(uint16_t eeAddr, const uint8_t* src, uint16_t len);
  void readBytes(uint16_t eeAddr, uint8_t* dst, uint16_t len) const;
  void findBestBlock();
  void initBuffers();
};

#endif
