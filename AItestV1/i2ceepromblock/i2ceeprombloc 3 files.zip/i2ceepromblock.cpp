// I2cEepromBlock.cpp
#include "I2cEepromBlock.h"

I2cEepromBlock::I2cEepromBlock(uint8_t i2cAddr, uint16_t userSize, uint8_t sdaPin, uint8_t sclPin)
  : _i2cAddr(i2cAddr), _userSize(userSize), _sdaPin(sdaPin), _sclPin(sclPin), _currentToken(0), _currentBlockIndex(-1), _dirty(false), _initialized(false), _bufA(nullptr), _bufB(nullptr), _activeBuf(nullptr), _inactiveBuf(nullptr), _state(State::Idle), _writeBlockIndex(0), _writeOffset(0) {

  _blockSize = HEADER_SIZE + _userSize;
  _numBlocks = EEPROM_SIZE / _blockSize;
}

I2cEepromBlock::~I2cEepromBlock() {
  delete[] _bufA;
  delete[] _bufB;
}

void I2cEepromBlock::begin() {
  Wire.begin(_sdaPin, _sclPin);
  initBuffers();
  findBestBlock();
  _initialized = true;
  _dirty = true;  // Trigger initial write if no valid block found
}

void I2cEepromBlock::initBuffers() {
  _bufA = new uint8_t[_userSize];
  _bufB = new uint8_t[_userSize];
  _activeBuf = _bufA;
  _inactiveBuf = _bufB;
  memset(_activeBuf, 0xFF, _userSize);  // Default all FF
}

uint16_t I2cEepromBlock::crc16_ccitt(const uint8_t* data, uint16_t len) const {
  uint16_t crc = 0xFFFF;
  while (len--) {
    crc ^= (uint16_t)(*data++) << 8;
    for (uint8_t i = 0; i < 8; ++i) {
      if (crc & 0x8000) crc = (crc << 1) ^ 0x1021;
      else crc <<= 1;
    }
  }
  return crc;
}

uint16_t I2cEepromBlock::blockBaseAddress(int blockIdx) const {
  return (uint16_t)blockIdx * _blockSize;
}

void I2cEepromBlock::readBytes(uint16_t eeAddr, uint8_t* dst, uint16_t len) const {
  Wire.beginTransmission(_i2cAddr);
  Wire.write((uint8_t)(eeAddr >> 8));
  Wire.write((uint8_t)(eeAddr & 0xFF));
  Wire.endTransmission(false);
  Wire.requestFrom(_i2cAddr, (uint8_t)len);
  for (uint16_t i = 0; i < len && Wire.available(); ++i) {
    dst[i] = Wire.read();
  }
}

void I2cEepromBlock::writeBytes(uint16_t eeAddr, const uint8_t* src, uint16_t len) {
  uint16_t addr = eeAddr;
  uint16_t remaining = len;

  while (remaining > 0) {
    uint8_t pageOffset = addr % PAGE_SIZE;
    uint8_t chunk = PAGE_SIZE - pageOffset;
    if (chunk > remaining) chunk = remaining;

    Wire.beginTransmission(_i2cAddr);
    Wire.write((uint8_t)(addr >> 8));
    Wire.write((uint8_t)(addr & 0xFF));
    for (uint8_t i = 0; i < chunk; ++i) {
      Wire.write(src[(len - remaining) + i]);
    }
    Wire.endTransmission();
    delay(WRITE_DELAY_MS);

    addr += chunk;
    remaining -= chunk;
  }
}

bool I2cEepromBlock::readBlock(int blockIdx, BlockHeader& header, uint8_t* buffer) const {
    if (blockIdx < 0 || blockIdx >= _numBlocks) return false;
    
    uint16_t base = blockBaseAddress(blockIdx);
    readBytes(base, (uint8_t*)&header, HEADER_SIZE);
    readBytes(base + HEADER_SIZE, buffer, _userSize);
    
    uint16_t calcCrc = crc16_ccitt(buffer, _userSize);
    return (calcCrc == header.crc);
}


void I2cEepromBlock::findBestBlock() {
  uint16_t bestToken = 0;
  int bestIdx = -1;

  uint8_t tempBuf[_userSize];
  BlockHeader tempHeader;

  for (int i = 0; i < _numBlocks; ++i) {
    if (readBlock(i, tempHeader, tempBuf)) {
      if (tempHeader.token >= bestToken) {
        bestToken = tempHeader.token;
        bestIdx = i;
        memcpy(_activeBuf, tempBuf, _userSize);
      }
    }
  }

  _currentToken = bestToken;
  _currentBlockIndex = bestIdx;
}

uint8_t* I2cEepromBlock::data() {
  return _activeBuf;
}
const uint8_t* I2cEepromBlock::data() const {
  return _activeBuf;
}

void I2cEepromBlock::markDirty() {
  if (_initialized) _dirty = true;
}

void I2cEepromBlock::task() {
  if (!_initialized) return;

  switch (_state) {
    case State::Idle:
      if (_dirty) {
        _writeBlockIndex = (_currentBlockIndex + 1) % _numBlocks;
        memcpy(_inactiveBuf, _activeBuf, _userSize);

        _preparedHeader.token = _currentToken + 1;
        _preparedHeader.crc = crc16_ccitt(_inactiveBuf, _userSize);

        _writeOffset = 0;
        _state = State::WritingHeader;
      }
      break;

    case State::WritingHeader:
      {
        uint16_t base = blockBaseAddress(_writeBlockIndex);
        uint8_t headerBytes[4];
        headerBytes[0] = _preparedHeader.token >> 8;
        headerBytes[1] = _preparedHeader.token & 0xFF;
        headerBytes[2] = _preparedHeader.crc >> 8;
        headerBytes[3] = _preparedHeader.crc & 0xFF;

        writeBytes(base, headerBytes, 4);
        _writeOffset = 0;
        _state = State::WritingData;
        break;
      }

    case State::WritingData:
      {
        if (_writeOffset >= _userSize) {
          _currentToken = _preparedHeader.token;
          _currentBlockIndex = _writeBlockIndex;
          std::swap(_activeBuf, _inactiveBuf);
          _dirty = false;
          _state = State::Idle;
          break;
        }

        uint16_t base = blockBaseAddress(_writeBlockIndex) + HEADER_SIZE;
        uint16_t addr = base + _writeOffset;
        uint8_t pageOffset = addr % PAGE_SIZE;
        uint8_t chunk = PAGE_SIZE - pageOffset;
        uint16_t remaining = _userSize - _writeOffset;
        if (chunk > remaining) chunk = remaining;

        writeBytes(addr, _inactiveBuf + _writeOffset, chunk);
        _writeOffset += chunk;
        break;
      }
  }
}
